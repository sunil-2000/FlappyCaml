(** CS 3110 Fall 2020 Final Project
    @author Brian Zhang (bsz6)
    @author Sunil Sabnis (svs57)
    @author Udai Khattar (uk49)
    @author Rishik Zaparde (rz293) *)
let hours_worked = 14